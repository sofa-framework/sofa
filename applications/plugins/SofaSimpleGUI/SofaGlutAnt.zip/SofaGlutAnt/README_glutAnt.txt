A Sofa simulation in a Glut window, with an AntTweakBar interface.
Francois Faure, 2014

You must install AntTweakBar and customize the .pro file accordingly
The .pro file includes Sofa.pri. This allows you to build this project outside the Sofa build system.

Example of run command (with working directory = this directory) 
glutAnt -f liver.scn

