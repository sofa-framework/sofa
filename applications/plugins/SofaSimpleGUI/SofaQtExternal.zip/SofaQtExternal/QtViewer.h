#ifndef QTVIEWER_H
#define QTVIEWER_H
#include <GL/glew.h>
#include <QGLWidget>
#include <SofaSimpleGUI/SofaGlInterface.h>

class QtViewer : public QGLWidget
{
    Q_OBJECT

// Sofa interface
sofa::newgui::SofaGlInterface sofaScene;  ///< The interface of the application with Sofa
sofa::newgui::SpringInteractor* drag;     ///< Mouse interactor

public:
    explicit QtViewer(QGLWidget *parent = 0);
    void initializeGL();
    void paintGL();
    void resizeGL(int w, int h);
    void keyPressEvent ( QKeyEvent * event );
    void keyReleaseEvent ( QKeyEvent * event );
    void mousePressEvent ( QMouseEvent * event );
    void mouseMoveEvent ( QMouseEvent * event );
    void mouseReleaseEvent ( QMouseEvent * event );


signals:

public slots:
    void animate();

};

#endif // QTVIEWER_H
