
#include <QApplication>
#include "QtViewer.h"
#include <GL/glut.h>
#include <iostream>
using namespace std;



int main(int argc, char** argv)
{
  glutInit(&argc,argv);

  // Read command lines arguments.
  QApplication application(argc,argv);

  // Instantiate the viewer
  QtViewer viewer;

  viewer.setWindowTitle("Qt application featuring Sofa");
  viewer.resize(500,500);

  // Make the viewer window visible on screen.
  viewer.show();

  // Run main loop.
  return application.exec();
}
