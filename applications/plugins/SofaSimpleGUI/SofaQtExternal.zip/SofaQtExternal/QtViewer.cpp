#include "QtViewer.h"
#include <QKeyEvent>
#include <QMouseEvent>
#include <QTimer>
#include <QMessageBox>
#include <GL/glut.h>
#include <iostream>
using namespace std;
//using namespace sofa::newgui;

GLfloat light_position[] = { 0.0, 0.0, 25.0, 0.0 };
GLfloat light_ambient[] = { 0.0, 0.0, 0.0, 0.0 };
GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 0.0 };
GLfloat light_specular[] = { 1.0, 1.0, 1.0, 0.0 };

GLfloat camera_position[] = { 0.0, 0.0, 25.0, 0.0 };
GLfloat znear = camera_position[2]-10;
GLfloat zfar = camera_position[2]+10;


QtViewer::QtViewer(QGLWidget *parent) :
    QGLWidget(parent)
{
    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(animate()));
    timer->start(40);

    // sofa
//    sofaScene.init("oneTet.scn");
    sofaScene.init("liver.scn");
    drag = NULL;

    QMessageBox::information( this, tr("Tip"), tr("Click and drag the control points to interact.") );
}

void QtViewer::initializeGL()
{
    glClearColor (0.0, 0.0, 0.0, 0.0);

    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glEnable(GL_DEPTH_TEST);

}

void QtViewer::paintGL()
{
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity ();
    gluLookAt ( camera_position[0],camera_position[1],camera_position[2], 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

    sofaScene.glDraw();

    // display a box, for debug
    glColor3f (1.0, 0.0, 0.0);
    glutWireCube (1.0);

}

void QtViewer::animate()
{
    sofaScene.animate();
    update();
}

void QtViewer::resizeGL(int w, int h)
{
    glViewport (0, 0, (GLsizei) w, (GLsizei) h);
    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    gluPerspective (55.0, (GLfloat) w/(GLfloat) h, znear, zfar );
    glMatrixMode (GL_MODELVIEW);
}

void QtViewer::keyPressEvent ( QKeyEvent * event )
{
    if( event->key() == Qt::Key_Shift ) cout << "Shift ";
    else if( event->key() == Qt::Key_Control ) cout << "Control ";
    else if( event->key() == Qt::Key_Alt ) cout << "Alt ";
    cout << event->text().toStdString();
}

void QtViewer::keyReleaseEvent ( QKeyEvent * /*event*/ )
{
    cout << endl;
}

void QtViewer::mousePressEvent ( QMouseEvent * event )
{
//    if( event->button() == Qt::LeftButton )
//        cout << "QtViewer::mousePressEvent, left button at ";
//    else if( event->button() == Qt::MiddleButton )
//        cout << "QtViewer::mousePressEvent, middle button at ";
//    else if( event->button() == Qt::RightButton )
//        cout << "QtViewer::mousePressEvent, right button at ";
//    cout << " at " << event->x() << ", " << this->height() -  event->y()<< endl;

        sofa::newgui::PickedPoint glpicked = sofaScene.pick(camera_position[0],camera_position[1],camera_position[2], event->x(), event->y() );
        if( glpicked )
        {
            drag = new sofa::newgui::SpringInteractor(glpicked);
            sofaScene.attach(drag);
                cout << "Particle glpicked: " << glpicked << endl;
//                sofaScene.printScene();
        }
        else {
            cout << "no particle glpicked" << endl;
        }


}

void QtViewer::mouseMoveEvent ( QMouseEvent * event )
{
//    int x=event->x(), y=this->height()-event->y();
//    cout << "QtViewer::mouseMove to " << x << ", " << y << endl;
    if( drag != NULL )
    {
        sofaScene.move(drag, event->x(), event->y());
    }
}

void QtViewer::mouseReleaseEvent ( QMouseEvent * /*event*/ )
{
//    if( event->button() == Qt::LeftButton )
//        cout << "QtViewer::mouseRelease, left button at ";
//    else if( event->button() == Qt::MiddleButton )
//        cout << "QtViewer::mouseRelease, middle button at ";
//    else if( event->button() == Qt::RightButton )
//        cout << "QtViewer::mouseRelease, right button at ";
//    cout << " at " << event->x() << ", " << this->height() -  event->y()<< endl;

    if( drag != NULL )
    {
        sofaScene.detach(drag);
        delete drag;
        drag = NULL;
    }

}

