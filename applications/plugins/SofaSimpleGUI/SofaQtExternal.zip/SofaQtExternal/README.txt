A simple Qt application with a Sofa simulation.
Qmake project file for linux, debug version.

Francois Faure, 2014
