A simple Qt application with a Sofa simulation.
Francois Faure, 2014

Qmake project file for linux.
Requires the activation of plugin SofaSimpleGui in the Sofa build.

The application tries to load a .scn scenefile on startup. This file is distributed in this directory. The application issues an error message in the console if it does not manage to load it. In this case, check directory/path issues between the executable and the scene file.


