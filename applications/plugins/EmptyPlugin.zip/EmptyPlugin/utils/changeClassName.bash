#!/bin/bash

# Replace a class name.
# Arguments: OldClassName NewClassName
# This script:
# - replaces the old class name by the new class name in all the files;
# - changes all file names containing the old class name 
#   by new names with the new class name;

# generates a lot of warning due to trying to commands like mv x x
# 
# 

# number of arguments must be 2
if ! test $# -eq 2 
then
	echo arguments: OldClassName NewClassName
	exit 1
fi
OldClassName=$1;
NewClassName=$2;

function ProcessDir
{
# Process each argument
for f in "$@"
do
if [ -f $f ]; then # replace string inside the file
sed -i s/$OldClassName/$NewClassName/g $f
fi
# replace file name 
NewName=`echo $f | sed s/$OldClassName/$NewClassName/g`;
mv $f $NewName ;  
# echo old name = $f;
# echo new name = $NewName;
if [ -d "$NewName" ]; then # Recursively travel the subdir
# echo "Process directory $NewName ---------- ";
cd "$NewName";
ProcessDir $(ls -1 );
cd ..;
# echo "leaving directory $f"
fi
done
}

ProcessDir *
