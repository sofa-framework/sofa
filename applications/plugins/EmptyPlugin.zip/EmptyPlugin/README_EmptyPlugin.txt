************************************
         EmptyPlugin plugin        
************************************

Brief description: 
Authors: 
License: 
Documentation: See doc/index.html

