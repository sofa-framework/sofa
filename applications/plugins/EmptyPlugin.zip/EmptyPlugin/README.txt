
************************************
*         EmptyPlugin plugin         *
************************************

Documentation: See doc/index.html

AUTHOR :
 - Michael Adam

LICENCE :



OTHER COMMENTS :
